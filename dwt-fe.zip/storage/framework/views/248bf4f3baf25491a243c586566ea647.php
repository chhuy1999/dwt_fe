<?php $__env->startSection('title', 'Danh sách chỉ số key'); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('template.sidebar.sidebarHopGiaoBan.sidebarLeft', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div id="mainWrap" class="mainWrap">
        <div class="mainSection">
            <div class="main">
                <div class="container-fluid">
                    <div class="mainSection_heading">
                        <h5 class="mainSection_heading-title">
                            Danh sách chỉ số key
                        </h5>
                        <div class="mainSection_card">
                            <div class="mainSection_content">
                                <div class="me-5" style="flex:1">Đơn vị: </div>
                                <div class="d-flex justify-content-start" style="flex:2"><strong>Kế toán</strong>
                                </div>
                            </div>
                            <div class="mainSection_content">
                                <div class="me-3">Trưởng đơn vị: </div>
                                <div class="d-flex justify-content-start"><strong>Nguyễn Thị Yến Hoa</strong></div>
                            </div>
                        </div>
                        <div id="mainSection_width" class="mainSection_thismonth d-flex align-items-center overflow-hidden">
                            <label class="">Tháng</label>
                            <input id="thismonth" value="<?php echo date('m/Y'); ?>" class="form-control" type="text" />
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-lg-12">
                            <div class="card mb-3">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between align-items-center pb-2">
                                        <div class="main_search d-flex">
                                            <i class="bi bi-search"></i>
                                            <input type="text" class="form-control" placeholder="Tìm kiếm chỉ số key">
                                        </div>
                                        <div class="main_action">
                                            <button id="exporttable" class="btn btn-danger" data-bs-toggle="modal"
                                                data-bs-target="#themMoiDinhMuc">
                                                <i class="bi bi-plus"></i>
                                                Thêm mới
                                            </button>
                                            <button id="exporttable" class="btn btn-outline-danger" data-bs-toggle="tooltip"
                                                data-bs-placement="top" title="Xuất file Excel">
                                                <i class="bi bi-download"></i>
                                                Xuất Excel
                                            </button>
                                        </div>
                                    </div>
                                    <div class='row'>
                                        <div class="col-md-12">
                                            <div class="position-relative">
                                                <table class="table table-responsive table-hover table-bordered">
                                                    <thead>
                                                        <tr>
                                                            <th style="width: 2%">STT</th>
                                                            <th style="width: 20%">Tên chỉ số key</th>
                                                            <th style="width: 10%">Đơn vị</th>
                                                            <th style="width: 66%">Mô tả</th>
                                                            <th style="width: 2%"></th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__currentLoopData = $listKeys->data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr>
                                                                <td>
                                                                    <div
                                                                        class="d-flex align-items-center justify-content-center">
                                                                        <?php echo e($key->id); ?>

                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div>
                                                                        <?php echo e($key->name); ?>

                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div>
                                                                        <?php echo e($key->unit && $key->unit->name); ?>

                                                                    </div>

                                                                </td>
                                                                <td>
                                                                    <div>
                                                                        <?php echo e($key->description); ?>

                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="dotdotdot" id="dropdownMenuButton1"
                                                                        data-bs-toggle="dropdown" aria-expanded="false"><i
                                                                            class="bi bi-three-dots-vertical"></i>
                                                                    </div>
                                                                    <ul class="dropdown-menu"
                                                                        aria-labelledby="dropdownMenuButton1">
                                                                        <li>
                                                                            <a class="dropdown-item" href="#"
                                                                                data-bs-toggle="modal"
                                                                                data-bs-target=<?php echo e('#suaMoiDinhMuc' . $key->id); ?>>
                                                                                <img style="width:16px;height:16px"
                                                                                    src="<?php echo e(asset('assets/img/edit.svg')); ?>" />
                                                                                Sửa
                                                                            </a>
                                                                        </li>
                                                                        <li>
                                                                            <a class="dropdown-item" href="#"
                                                                                data-bs-toggle="modal"
                                                                                data-bs-target="#xoaThuocTinh<?php echo e($key->id); ?>"
                                                                                data-repeater-delete>
                                                                                <img style="width:16px;height:16px"
                                                                                    src="<?php echo e(asset('assets/img/trash.svg')); ?>" />
                                                                                Xóa
                                                                            </a>
                                                                        </li>
                                                                    </ul>
                                                                </td>
                                                            </tr>
                                                            <!-- Modal Sửa chỉ số key -->
                                                            <div class="modal fade" id="<?php echo e('suaMoiDinhMuc' . $key->id); ?>"
                                                                tabindex="-1" aria-labelledby="exampleModalLabel"
                                                                aria-hidden="true">
                                                                <div class="modal-dialog modal-dialog-centered"
                                                                    style="max-width:38%;">
                                                                    <div class="modal-content">
                                                                        <div class="modal-header text-center">
                                                                            <h5 class="modal-title w-100"
                                                                                id="exampleModalLabel">Sửa chỉ số key</h5>
                                                                            <button type="button" class="btn-close"
                                                                                data-bs-dismiss="modal"
                                                                                aria-label="Close"></button>
                                                                        </div>
                                                                        <form method="POST"
                                                                            action="/danh-muc-chi-so-key/<?php echo e($key->id); ?>">
                                                                            <?php echo csrf_field(); ?>
                                                                            <?php echo method_field('PUT'); ?>
                                                                            <div class="modal-body">
                                                                                <div class="row">
                                                                                    <div class="col-sm-8">
                                                                                        <div
                                                                                            class="mb-3 d-flex align-items-center  justify-content-between">
                                                                                            <div
                                                                                                class="modal_body-title col-sm-3">
                                                                                                Tên chỉ số key <span
                                                                                                    class="text-danger">*</span>
                                                                                            </div>
                                                                                            <div class="col-sm-9">
                                                                                                <input class="form-control"
                                                                                                    type="text"
                                                                                                    name="name"
                                                                                                    value="<?php echo e($key->name); ?>">
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="col-sm-4">
                                                                                        <div
                                                                                            class="mb-3 d-flex align-items-center  justify-content-between">
                                                                                            <div
                                                                                                class="modal_body-title col-sm-3">
                                                                                                Đơn vị <span
                                                                                                    class="text-danger">*</span>
                                                                                            </div>
                                                                                            <div class="col-sm-9">
                                                                                                <select
                                                                                                    class="selectpicker"
                                                                                                    title="Chọn đơn vị"
                                                                                                    name="unit_id">
                                                                                                    <?php $__currentLoopData = $listUnits->data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                                        <?php if($unit->id != $key->unit_id): ?>
                                                                                                            <option
                                                                                                                value="<?php echo e($unit->id); ?>">
                                                                                                                <?php echo e($unit->name); ?>

                                                                                                            </option>
                                                                                                        <?php else: ?>
                                                                                                            <option
                                                                                                                value="<?php echo e($unit->id); ?>"
                                                                                                                selected>
                                                                                                                <?php echo e($unit->name); ?>

                                                                                                            </option>
                                                                                                        <?php endif; ?>
                                                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                                </select>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="col-sm-12">
                                                                                        <div
                                                                                            class="mb-3 d-flex align-items-center  justify-content-between">
                                                                                            <div
                                                                                                class="modal_body-title col-sm-2">
                                                                                                Mô tả chỉ số <span
                                                                                                    class="text-danger">*</span>
                                                                                            </div>
                                                                                            <div class="col-sm-10">
                                                                                                <textarea class="form-control" name="description"><?php echo e($key->description); ?></textarea>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>

                                                                                </div>
                                                                            </div>
                                                                            <div class="modal-footer">
                                                                                <button type="button"
                                                                                    class="btn btn-outline-danger"
                                                                                    data-bs-dismiss="modal">Hủy</button>
                                                                                <button type="submit"
                                                                                    class="btn btn-danger">Lưu</button>
                                                                            </div>
                                                                        </form>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                            
                                                            <div class="modal fade" id="xoaThuocTinh<?php echo e($key->id); ?>"
                                                                tabindex="-1" aria-labelledby="exampleModalLabel"
                                                                aria-hidden="true">
                                                                <div class="modal-dialog modal-dialog-centered">
                                                                    <div class="modal-content">
                                                                        <div class="modal-header">
                                                                            <h5 class="modal-title text-danger"
                                                                                id="exampleModalLabel">Xóa chỉ số key</h5>
                                                                            <button type="button" class="btn-close"
                                                                                data-bs-dismiss="modal"
                                                                                aria-label="Close"></button>
                                                                        </div>
                                                                        <div class="modal-body">
                                                                            Bạn có thực sự muốn xoá đinh mức này không?

                                                                        </div>
                                                                        <div class="modal-footer">
                                                                            <button type="button"
                                                                                class="btn btn-outline-danger"
                                                                                data-bs-dismiss="modal">Hủy</button>
                                                                            <form
                                                                                action="/danh-muc-chi-so-key/<?php echo e($key->id); ?>"
                                                                                method="POST">
                                                                                <?php echo csrf_field(); ?>
                                                                                <?php echo method_field('DELETE'); ?>
                                                                                <button type="submit"
                                                                                    class="btn btn-danger"
                                                                                    id="deleteRowElement">Có, tôi muốn
                                                                                    xóa</button>
                                                                            </form>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer">
                <div class="container">Copyright © 2023 S-Team. All rights reserved.</div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('template.sidebar.sidebarHopGiaoBan.sidebarRight', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Modal Thêm chỉ số key -->
    <div class="modal fade" id="themMoiDinhMuc" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" style="max-width:38%;">
            <div class="modal-content">
                <div class="modal-header text-center">
                    <h5 class="modal-title w-100" id="exampleModalLabel">Thêm mới chỉ số key</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form method="POST" action="/danh-muc-chi-so-key">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-sm-8">
                                <div class="mb-3 d-flex align-items-center  justify-content-between">
                                    <div class="modal_body-title col-sm-3">
                                        Tên chỉ số key <span class="text-danger">*</span>
                                    </div>
                                    <div class="col-sm-9">
                                        <input class="form-control" type="text" placeholder="Nhập tên chỉ số key"
                                            name="name">
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="mb-3 d-flex align-items-center  justify-content-between">
                                    <div class="modal_body-title col-sm-3">
                                        Đơn vị <span class="text-danger">*</span>
                                    </div>
                                    <div class="col-sm-9">
                                        <select class="selectpicker" title="Chọn đơn vị" name="unit_id">
                                            <?php $__currentLoopData = $listUnits->data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($unit->id); ?>"><?php echo e($unit->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <div class="mb-3 d-flex align-items-center  justify-content-between">
                                    <div class="modal_body-title col-sm-2">
                                        Mô tả chỉ số <span class="text-danger">*</span>
                                    </div>
                                    <div class="col-sm-10">
                                        <textarea class="form-control" placeholder="Nhập mô tả chỉ số" name="description"></textarea>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-outline-danger" data-bs-dismiss="modal">Hủy</button>
                        <button type="submit" class="btn btn-danger">Lưu</button>
                    </div>
                </form>
            </div>
        </div>
    </div>






<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer-script'); ?>
    <!-- ChartJS -->
    <script type="text/javascript" src="<?php echo e(asset('assets/plugins/chartjs/chart.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/plugins/chartjs/chartjs-plugin-stacked100@1.0.0')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/plugins/chartjs/chartjs-plugin-datalabels@2.0.0')); ?>"></script>

    <script type="text/javascript" src="<?php echo e(asset('assets/vendor/jquery/jquery-ui.min.js')); ?>"></script>
    <script type="text/javascript"
        src="<?php echo e(asset('assets/plugins/jquery-datetimepicker/jquery.datetimepicker.full.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/jquery-datetimepicker/custom-datetimepicker.js')); ?>"></script>

    <script src="<?php echo e(asset('/assets/js/chart_hopgiaoban/doughnutChiSo.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\www\dwt-fe\resources\views/CauHinh/danhMucChiSoKey.blade.php ENDPATH**/ ?>